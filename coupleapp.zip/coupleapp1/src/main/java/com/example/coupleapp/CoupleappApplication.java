package com.example.coupleapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoupleappApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoupleappApplication.class, args);
    }

}
