package com.example.coupleapp.exception;

public class AlbumContentNotFoundException extends Throwable {
    public AlbumContentNotFoundException(String s) {
    }
}
