package com.example.coupleapp.dto;

import lombok.Data;

@Data
public class SettingsDTO {
    private Long settingId;
    private Long memberId;
    private Long partnerId;

    // Getters and setters (You can use Lombok for this)
}
